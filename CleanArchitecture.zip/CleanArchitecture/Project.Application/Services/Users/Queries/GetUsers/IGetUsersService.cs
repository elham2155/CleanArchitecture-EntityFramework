﻿using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Project.Application.Services.Users.Queries.GetUsers
{
    public interface IGetUsersService
    {
        ResultGetUsersDto Execute(RequestGetUsersDto request);
    }
}
