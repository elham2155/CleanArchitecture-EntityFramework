﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Project.Common.Dtos;

namespace Project.Application.Services.Users.Queries.GetRoles
{
    public interface IGetRolesService
    {
        ResultDto<List<RolesDto>> Execute();
    }

   
}
