﻿using System;
using Project.Application.Interfaces.Contexts;
using Project.Common.Dtos;

namespace Project.Application.Services.Users.Commands.RemoveUser
{
    public class RemoveUserService : IRemoveUserService
    {
        private readonly IDatabaseContext _context;

        public RemoveUserService(IDatabaseContext context)
        {
            _context = context;
        }
        public ResultDto Execute(int UserId)
        {
            var user = _context.Users.Find(UserId);
            if (user == null)
            {
                return new ResultDto
                {
                    IsSuccess = false,
                    Message = "User not found!"
                };
            }
            user.RemoveTime = DateTime.Now;
            user.IsRemoved = true;
            _context.SaveChanges();
            return new ResultDto()
            {
                IsSuccess = true,
                Message = "Deleting done!"
            };
        }
    }
}
