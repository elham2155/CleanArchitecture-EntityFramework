﻿using System;
using System.Collections.Generic;
using Project.Application.Interfaces.Contexts;
using Project.Common.Dtos;
using Project.Domain.Entities.Users;

namespace Project.Application.Services.Users.Commands.RegisterUser
{
    public class RegisterUserService : IRegisterUserService
    {
        //---connect to DB---since we don't have access to persistance layer,
        //---we shoul use IDatabaseContext from this layer
        private readonly IDatabaseContext _context;

        public RegisterUserService(IDatabaseContext context)
        {
            _context = context;
        }

        public ResultDto<ResultRegisterUseDto> Execute(RequestRegisterUseDto request)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(request.Email))
                {
                    return new ResultDto<ResultRegisterUseDto>()
                    {
                        Data = new ResultRegisterUseDto()
                        {
                            UserId = 0,
                        },
                        IsSuccess = false,
                        Message = "Enter Email"
                    };
                }

                if (string.IsNullOrWhiteSpace(request.FullName))
                {
                    return new ResultDto<ResultRegisterUseDto>()
                    {
                        Data = new ResultRegisterUseDto()
                        {
                            UserId = 0,
                        },
                        IsSuccess = false,
                        Message = "Enter FullName"
                    };
                }
                if (string.IsNullOrWhiteSpace(request.Password))
                {
                    return new ResultDto<ResultRegisterUseDto>()
                    {
                        Data = new ResultRegisterUseDto()
                        {
                            UserId = 0,
                        },
                        IsSuccess = false,
                        Message = "Enter Password"
                    };
                }
                if (request.Password != request.RePassword)
                {
                    return new ResultDto<ResultRegisterUseDto>()
                    {
                        Data = new ResultRegisterUseDto()
                        {
                            UserId = 0,
                        },
                        IsSuccess = false,
                        Message = "Confirm your Password"
                    };
                }

                User user = new User()
                {
                    Email = request.Email,
                    FullName = request.FullName,
                    Password = request.Password //HashPassword.Execute(request.Password),
                };

                List<UserRole> userRoles = new List<UserRole>();

                foreach (var item in request.Roles)
                {
                    var roles = _context.Roles.Find(item.Id);
                    userRoles.Add(new UserRole
                    {
                        Role = roles,
                        RoleId = roles.Id,
                        User = user,
                        UserId = user.Id,
                    });
                }
                user.UserRoles = userRoles;

                _context.Users.Add(user);

                _context.SaveChanges();

                return new ResultDto<ResultRegisterUseDto>()
                {
                    Data = new ResultRegisterUseDto()
                    {
                        UserId = user.Id,

                    },
                    IsSuccess = true,
                    Message = "Registration done!",
                };
            }
            catch (Exception)
            {
                return new ResultDto<ResultRegisterUseDto>()
                {
                    Data = new ResultRegisterUseDto()
                    {
                        UserId = 0,
                    },
                    IsSuccess = false,
                    Message = "No registration !"
                };
            }



        }
    }
}
