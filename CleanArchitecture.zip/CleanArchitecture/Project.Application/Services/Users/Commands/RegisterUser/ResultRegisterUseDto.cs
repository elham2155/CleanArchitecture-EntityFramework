﻿namespace Project.Application.Services.Users.Commands.RegisterUser
{
    public class ResultRegisterUseDto //service output
    {
        public int UserId { get; set; }
        
    }
}
