﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project.Common.Dtos;

namespace Project.Application.Services.Users.Commands.RegisterUser
{
    public interface IRegisterUserService
    {
        ResultDto<ResultRegisterUseDto> Execute(RequestRegisterUseDto request);
    }
}
