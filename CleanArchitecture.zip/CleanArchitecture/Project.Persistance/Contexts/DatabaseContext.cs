﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Project.Application.Interfaces.Contexts;
using Project.Common.Roles;
using Project.Domain.Entities.Users;

namespace Project.Persistance.Contexts
{
    public class DatabaseContext : DbContext , IDatabaseContext
    {
        public DatabaseContext(DbContextOptions options):base(options)
        {

        }

        public DbSet<User> Users { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<UserRole> UserRoles { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //seeding
            modelBuilder.Entity<Role>().HasData(new Role { Id = 1, Name = nameof(UserRolesConst.Admin) });
            modelBuilder.Entity<Role>().HasData(new Role { Id = 2, Name = nameof(UserRolesConst.Operator) });
            modelBuilder.Entity<Role>().HasData(new Role { Id = 3, Name = nameof(UserRolesConst.Customer) });

            //to have unique email address for users
            modelBuilder.Entity<User>().HasIndex(u => u.Email).IsUnique();

            //Query filter not showing deleted users
            modelBuilder.Entity<User>().HasQueryFilter(u=>!u.IsRemoved);
        }
    }
}
